const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio');
const secrets = require('./env');

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0; 
const app = express();
const port = 3000;

// Disable certificate validation (use cautiously in production)
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));

// In-memory OTP storagec
const otps = {};

// Twilio credentials
const accountSid = secrets.TWILIO_ACCOUNT_SID;
const authToken = secrets.TWILIO_AUTH_TOKEN;
const client = new twilio(accountSid, authToken);


// Serve home page for phone number input
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Generate and send OTP
app.post('/generate-otp', (req, res) => {
  const phoneNumber = req.body.phoneNumber;

  // Validate phone number
  if (!/^\d{10}$/.test(phoneNumber)) {
    return res.status(400).send('Invalid phone number. Please enter a valid 10-digit number.');
  }







  
  // Generate OTP
  const otp = Math.floor(100000 + Math.random() * 900000);
  otps[phoneNumber] = otp;

  // Send OTP via WhatsApp
  sendWhatsAppMessage(phoneNumber, `Your OTP is: ${otp}`)
    .then(() => {
      console.log(`OTP sent to ${phoneNumber}: ${otp}`);
      res.sendFile(__dirname + '/verify.html'); // Redirect to OTP verification page
    })
    .catch((error) => {
      console.error('Error sending OTP:', error);
      res.status(500).send('Failed to send OTP. Please try again.');
    });
});

// Verify OTP
app.post('/verify-otp', (req, res) => {
  const phoneNumber = req.body.phoneNumber;
  const submittedOtp = req.body.otp;

  // Validate OTP
  if (otps[phoneNumber] && parseInt(submittedOtp, 10) === otps[phoneNumber]) {
    delete otps[phoneNumber]; // Remove OTP after use

    // Send confirmation message
    sendWhatsAppMessage(phoneNumber, 'Customer verified. Package successfully delivered!')
      .then(() => {
        console.log(`OTP verified for ${phoneNumber}`);
        res.sendFile(__dirname + '/Success.html'); // Redirect to success page
      })
      .catch((error) => {
        console.error('Error sending confirmation message:', error);
        res.status(500).send('Verification successful, but confirmation message failed.');
      });
  } else {
    console.log(`Invalid OTP for ${phoneNumber}`);
    res.sendFile(__dirname + '/Retry.html'); // Redirect to retry page
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});

// Twilio WhatsApp messaging
function sendWhatsAppMessage(to, message) {
  return client.messages.create({
    body: message,
    from: '+15412562406', // Twilio WhatsApp sandbox number
    to: `+91${to}`,
  });
}


